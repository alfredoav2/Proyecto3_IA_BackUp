#pragma once
#include <iostream>
#include <vector>
using std::cout; using std::endl;
template <class T>
class TreeNode {
private:
    //T data;
public:
    T data;

    TreeNode<T>* parent = nullptr;
    TreeNode<T>* bestNextMove = nullptr;

    int generation;
    int value;
    bool maximum = true;
    bool endGame = false;
    bool visitado = false;

    std::vector<TreeNode<T>*> v;
    T getData() {
        return data;
    }
    TreeNode() {}
    TreeNode(T d) : data(d) {

    }
    TreeNode(T d, int gen, int val, bool max, bool endgame) : data(d), generation(gen), value(val), endGame(endgame) {

        if (gen % 2 != 0) {
            maximum = false;
        }
        else {
            maximum = true;
        }
    }
    ~TreeNode() {

    }
};