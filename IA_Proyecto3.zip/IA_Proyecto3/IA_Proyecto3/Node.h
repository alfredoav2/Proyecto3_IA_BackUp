#pragma once
template <class T>
class Node {
public:
	T dato;
	bool end = false;
	Node* next = nullptr;
	Node(T d) : dato(d) {};
};