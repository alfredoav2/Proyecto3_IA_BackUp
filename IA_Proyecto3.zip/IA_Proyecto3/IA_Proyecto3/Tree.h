#pragma once
#include "TreeNode.h"
#include <list>
#include <stack>
using std::cout; using std::endl;
template <class T>
class Tree {
    typedef TreeNode<T> TN;
private:
    int intentos = 0;
public:
    TreeNode<T>* root = nullptr;
    TreeNode<T>* last = nullptr;

    std::vector<T>ll;
    Tree() {};
    Tree(T data) {
        if (!root) {
            root = new TN(data);
            ll.push_back(root->getData());
            last = root;
        }
    }
    /**
    * Busca un elemento en especifico en todo el arbol con un DFS
    *
    * @param data es el elemento que se busca
    */

    TN* search(T data) {
        if (root) {
            TN* tmp = last;
            if (last->getData() == data) {
                return last;
            }
            else {
                for (int i = 0; i < tmp->v.size(); i++) {
                    last = tmp->v.at(i);
                    if (search(data) != nullptr) {
                        return search(data);
                    }
                    last = root;
                }
            }
            return nullptr;
        }
        last = root;
        return nullptr;
    }

    void insert(T dataParent, T data,int val) {
        if (root) {
            //last = root;
            if (search(data) == nullptr && search(dataParent) != nullptr) {
                last = root;
                TN* tmp = root;
                while (tmp) {
                    if (!tmp->endGame) {
                        if (tmp->getData() == dataParent) {
                            tmp->v.push_back(new TN(data, tmp->generation + 1, val, true, false));
                            last = root;
                            break;
                        }
                        else {
                            tmp = searchGato(dataParent);
                            tmp->v.push_back(new TN(data, tmp->generation + 1, val, !tmp->maximum, false));
                            last = root;
                            break;
                        }
                    }
                }
            }
            else {
                last = root;
                //cout << data << endl;
            }
        }
        else if (!root && search(data) == nullptr) {
            root = new TN(data);
            last = root;
        }
    }

    TN* searchGato(T data) {
        if (root) {
            TN* tmp = last;
            int paresidos = 0;
            for (int i = 0; i < 3; i++) {
                for (int j = 0; j < 3; j++) {
                    if (last->getData().at(0)[i][j] == data.at(0)[i][j]) {
                        paresidos++;
                    }
                }
            }

            if (paresidos >= 9) {
                return last;
            }
            else {
                for (int i = 0; i < tmp->v.size(); i++) {
                    last = tmp->v.at(i);

                    if (searchGato(data) != nullptr) {
                        return searchGato(data);
                    }
                    last = root;
                }
            }
            return nullptr;
        }
        last = root;
        return nullptr;
    }
    /**
    * Incerta un nuevo elemento dentro un elemento existente del arbol
    *
    * @return si encuentra el elemento regresa un apuntador a ese elemento y si no lo encuentra regresa in nullptr
    *
    * @param data parent es el elemento donde se incertara el data, data es el elemento que se incertata dentro del data parent
    */
    void insertGato(TN* dataParent, TN* data) {
        if (root) {
            last = root;
            TN* tmp = root;
            //while (tmp) {
                if (tmp == dataParent) {
                    data->parent = dataParent;
                    tmp->v.push_back(data);
                    last = root;
                    if (data->value != 0) {
                        ChangeParentHeuristic(data, data->value);
                    }
                    //break;
                }
                else {
                    tmp = dataParent;
                    data->parent = dataParent;
                    tmp->v.push_back(data);
                    last = root;
                    if (data->value != 0) {
                        ChangeParentHeuristic(data, data->value);
                    }
                    //break;
                }
           
            //}
        }
        else if (!root) {
            root = data;
            root->generation = 0;
            root->value = 0;
            ll.push_back(root->getData());
            last = root;
        }
    }

    void ChangeParentHeuristic(TN* node, int val) {

            TN* tmp = node->parent;

            if (tmp) {
                if (tmp->maximum && (tmp->value < val || tmp->value == 0)) {
                    tmp->value = val;
                    tmp->bestNextMove = node;
                    ChangeParentHeuristic(tmp, tmp->value);
                }
                else if (!tmp->maximum && (tmp->value > val || tmp->value == 0)) {
                    tmp->value = val;
                    tmp->bestNextMove = node;
                    ChangeParentHeuristic(tmp, tmp->value);
                }
            }
    }

    void insertM(T dataParent, T data) {
        if (root) {
            //last = root;
            if (search(data) == nullptr && search(dataParent) != nullptr) {
                last = root;
                TN* tmp = root;
                while (tmp) {
                    if (tmp->getData() == dataParent) {
                        tmp->v.push_back(new TN(data));
                        last = root;
                        break;
                    }
                    else {
                        tmp = search(dataParent);
                        tmp->v.push_back(new TN(data));
                        last = root;
                        break;
                    }
                }
            }
            else {
                last = root;
                //cout << data << endl;
            }
        }
        else if (!root && search(dataParent) == nullptr) {
            root = new TN(data);
            root->generation = 0;
            root->value = 0;
            ll.push_back(root->getData());
            last = root;
        }
    }

    TN* SearchExitMaze(TN* tmp) {
        if (root) {
            cout << tmp->getData() << endl;
            std::stack<TN*> visited;
            visited.push(tmp);
            int x = 0;
            if (tmp->getData()->end) {
                cout << "Se encontro la salida." << endl;
                return tmp;
            }

            for (int i = 0; i < tmp->v.size(); i++) {
                SearchExitMaze(tmp->v[i]);
            }
            return nullptr;

        }
        return nullptr;
    }
    /**
    * Elimina un elemento especifico y a sus hijos del arbol
    *
    * @param data es el elemento que se busca eliminar
    */
    void erase(T data) {
        if (root) {
            if (search(data)) {
                last = root;
                if (searchParend(data)) {
                    TN* tmp = searchParend(data);
                    last = tmp;
                    if (search(data)->getData() == tmp->v.at(tmp->v.Size() - 1)->getData()) {
                        tmp->v.pop_back();
                    }
                    else {
                        tmp->v.recorrer(search(data));
                    }
                    last = root;
                }
            }
            last = root;
        }
    }
    /**
    * Busca el elemento padre del un elemento en especifico
    *
    * @return si encuentra al padre regresa un apuntador al padre y si no lo encuentra regresa un nullptr
    *
    * @param data es le elemento al que se le quiere encontrar su padre
    */
    TN* searchParend(T data) {
        if (root) {
            TN* tmp = last;
            for (int i = 0; i < tmp->v.Size(); i++) {
                if (tmp->v.at(i)->getData() == data) {
                    return tmp;
                }
            }
            for (int i = 0; i < tmp->v.Size(); i++) {
                last = tmp->v.at(i);
                if (searchParend(data) != nullptr) {
                    return searchParend(data);
                }
                last = root;
            }
        }
        last = root;
        return nullptr;
    }

    void ImprimeGato(TN* currentNode) {
        TN* tmp = currentNode->bestNextMove;
        for (int i = 1; i < 4; i++) {
            for (int j = 1; j < 4; j++) {
                if (tmp->getData().at(0)[i - 1][j - 1] == 1) {
                    cout << "X";
                }
                else if (tmp->getData().at(0)[i - 1][j - 1] == 2) {
                    cout << "O";
                }
                else {
                    cout << "_";
                }
                if (j == 3 && i != 0) {
                    cout << endl;
                }
                else {
                    cout << "|";
                }
            }
        }

        if (tmp->endGame && !tmp->maximum) {
            cout << "jaja que malo" << endl;
        }
        else if (tmp->endGame && tmp->maximum) {
            cout << "mejor me voy" << endl;
        }
        else {
            int posx;
            int posy;
            std::cin >> posx;
            std::cin >> posy;

            ImprimeGato(MoveToPlayerModeNode(tmp, posx, posy));
        }
        //cout << posx << endl;
        //cout << tmp->value << endl;
    }

    TN* MoveToPlayerModeNode(TN* currentNode ,int x, int y) {
        for(int i = 0; i < currentNode->v.size(); i++){
            TN* tmp = currentNode->v.at(i);
            if (tmp->getData().at(0)[x][y] == 2) {
                return currentNode->v[i];
            }
        }

        return currentNode->parent;
    }
    /**
    * Imprime todo el contenido del arbol
    */
    //void imprime() {
    //    if (root /*&& ll.sizeN()>0*/) {
    //        TN* tmp = last;
    //        if (tmp->v.size() <= 0) {
    //            cout << search(ll[0])->getData() << " <- []" << endl;
    //        }
    //        else {
    //            cout << tmp->getData() << " <- ";
    //            cout << "[";
    //            for (int i = 0; i < tmp->v.size(); i++) {
    //                ll.push_back(tmp->v.at(i)->getData());
    //                cout << tmp->v.at(i)->getData();
    //                if (i != tmp->v.size() - 1) {
    //                    cout << ", ";
    //                }
    //                else {
    //                    cout << "]" << endl;
    //                }
    //            }
    //        }
    //        if (ll.size() > 1) {
    //            last = root;

    //            ll.erase(ll.begin());
    //            last = search(ll[0]);
    //            imprime();
    //        }
    //    }
    //    if (ll.size() <= 1) {
    //        ll[0] = root->getData();
    //        last = root;
    //    }
    //}
};