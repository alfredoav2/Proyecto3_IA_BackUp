#pragma once
#include <iostream>
#include "Tree.h"
#include "Node.h"
class Maze
{
private:
	Node<int>* mazeBuild[7][7] = {
		{new Node<int>(0), new Node<int>(0), new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(0), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(1), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(1), new Node<int>(1), new Node<int>(1), new Node<int>(0), new Node<int>(1), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(0), new Node<int>(1), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(1), new Node<int>(1), new Node<int>(1), new Node<int>(0), new Node<int>(1), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(1), new Node<int>(1), new Node<int>(1), new Node<int>(0)},
		{new Node<int>(0), new Node<int>(0), new Node<int>(0), new Node<int>(1), new Node<int>(0), new Node<int>(0), new Node<int>(0)}
	};

public:

	void Start() {
		Tree<Node<int>*> m(mazeBuild[3][0]);

		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				std::cout << mazeBuild[i][j]->dato << " ";
			}
			std::cout << std::endl;
		}

		//m.insertM(mazeBuild[3][0], mazeBuild[3][0]);
		m.insertM(mazeBuild[3][0], mazeBuild[3][1]);
		m.insertM(mazeBuild[3][1], mazeBuild[3][2]);
		m.insertM(mazeBuild[3][2], mazeBuild[2][2]);
		m.insertM(mazeBuild[2][2], mazeBuild[1][2]);
		m.insertM(mazeBuild[1][2], mazeBuild[1][1]);
		m.insertM(mazeBuild[2][2], mazeBuild[2][3]);
		m.insertM(mazeBuild[2][3], mazeBuild[2][4]);
		m.insertM(mazeBuild[2][4], mazeBuild[1][4]);
		m.insertM(mazeBuild[1][4], mazeBuild[1][5]);
		m.insertM(mazeBuild[2][4], mazeBuild[3][4]);
		m.insertM(mazeBuild[3][4], mazeBuild[3][5]);
		m.insertM(mazeBuild[3][5], mazeBuild[4][5]);
		m.insertM(mazeBuild[4][5], mazeBuild[5][5]);
		m.insertM(mazeBuild[5][5], mazeBuild[5][4]);
		m.insertM(mazeBuild[5][4], mazeBuild[5][3]);
		m.insertM(mazeBuild[5][3], mazeBuild[5][2]);
		m.insertM(mazeBuild[5][2], mazeBuild[5][1]);
		m.insertM(mazeBuild[3][5], mazeBuild[3][6]);
		mazeBuild[3][6]->end = true;

		for (int i = 0; i < 7; i++) {
			for (int j = 0; j < 7; j++) {
				std::cout << "(" << j << ", " << i << ") " <<mazeBuild[j][i] << " ";
			}
			std::cout << std::endl;
		}

		m.SearchExitMaze(m.root);
	}

};