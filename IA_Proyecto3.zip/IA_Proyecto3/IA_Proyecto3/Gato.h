#pragma once
#include <iostream>
#include <queue>
#include <array>
#include "Tree.h"

class Gato
{
public:
	Tree <std::array<short[3][3], 1>> a;

	std::array<short[3][3], 1> arrayRoot;

	void Start(){
		a.insert(arrayRoot, arrayRoot,0);

		TreeGenerator();
		a.ImprimeGato(a.root);
	}

	void TreeGenerator(){
		short shapeToPlace = 1;
		short sero = 0;
		std::queue <TreeNode<std::array<short[3][3], 1>>*>sons;
		sons.push(a.root);
		while (sons.size() > 0) {
			//if (sons.front()->endGame == false) {
				for (int i = 0; i < 3; i++) {
					for (int j = 0; j < 3; j++) {
						if (sons.front()->getData().at(0)[i][j] == 0) {

							std::array<short[3][3], 1> arrSon;
							arrSon = sons.front()->getData();

							arrSon.at(0)[i][j] = shapeToPlace;

							if (  ((arrSon.at(0)[0][0] == 1 && arrSon.at(0)[0][1] == 1 && arrSon.at(0)[0][2] == 1)
								|| (arrSon.at(0)[0][1] == 1 && arrSon.at(0)[1][1] == 1 && arrSon.at(0)[2][1] == 1)
								|| (arrSon.at(0)[0][2] == 1 && arrSon.at(0)[1][2] == 1 && arrSon.at(0)[2][2] == 1)
								|| (arrSon.at(0)[0][0] == 1 && arrSon.at(0)[0][1] == 1 && arrSon.at(0)[0][2] == 1)
								|| (arrSon.at(0)[1][0] == 1 && arrSon.at(0)[1][1] == 1 && arrSon.at(0)[1][2] == 1)
								|| (arrSon.at(0)[2][0] == 1 && arrSon.at(0)[2][1] == 1 && arrSon.at(0)[2][2] == 1)
								|| (arrSon.at(0)[0][0] == 1 && arrSon.at(0)[1][1] == 1 && arrSon.at(0)[2][2] == 1)
								|| (arrSon.at(0)[2][0] == 1 && arrSon.at(0)[1][1] == 1 && arrSon.at(0)[0][2] == 1))

								|| 

								  ((arrSon.at(0)[0][0] == 2 && arrSon.at(0)[0][1] == 2 && arrSon.at(0)[0][2] == 2)
								|| (arrSon.at(0)[0][1] == 2 && arrSon.at(0)[1][1] == 2 && arrSon.at(0)[2][1] == 2)
								|| (arrSon.at(0)[0][2] == 2 && arrSon.at(0)[1][2] == 2 && arrSon.at(0)[2][2] == 2)
								|| (arrSon.at(0)[0][0] == 2 && arrSon.at(0)[0][1] == 2 && arrSon.at(0)[0][2] == 2)
								|| (arrSon.at(0)[1][0] == 2 && arrSon.at(0)[1][1] == 2 && arrSon.at(0)[1][2] == 2)
								|| (arrSon.at(0)[2][0] == 2 && arrSon.at(0)[2][1] == 2 && arrSon.at(0)[2][2] == 2)
								|| (arrSon.at(0)[0][0] == 2 && arrSon.at(0)[1][1] == 2 && arrSon.at(0)[2][2] == 2)
								|| (arrSon.at(0)[2][0] == 2 && arrSon.at(0)[1][1] == 2 && arrSon.at(0)[0][2] == 2))
								) {

								//std::cout << arrSon.at(0)[0][1] << std::endl;

								int value = 0;

								if (shapeToPlace == 1) {
									value = 1000 - sons.front()->generation;
								}
								if (shapeToPlace == 2) {
									value = -1000 + sons.front()->generation;
								}

								a.insertGato(sons.front(), new TreeNode<std::array<short[3][3], 1>>(arrSon, sons.front()->generation + 1, value, true, true));
							}
							else {
								a.insertGato(sons.front(), new TreeNode<std::array<short[3][3], 1>>(arrSon, sons.front()->generation + 1, 0, true, false));
								sons.push(sons.front()->v[sons.front()->v.size() - 1]);

							}

						}
					}
				}
			//}
			
			sons.pop();

			if (!sons.empty()) {
				if (sons.front()->maximum == true) {
					shapeToPlace = 1;
				}
				else if (sons.front()->maximum == false) {
					shapeToPlace = 2;
				}
			}
		}
		
	}
};

/*if (&& (arrSon.at(0)[0][0] != 0 && arrSon.at(0)[1][0] != 0 && arrSon.at(0)[2][0] != 0
&& arrSon.at(0)[0][1] != 0 && arrSon.at(0)[1][1] != 0 && arrSon.at(0)[2][1] != 0
&& arrSon.at(0)[0][2] != 0 && arrSon.at(0)[1][2] != 0 && arrSon.at(0)[2][2] != 0)) {*/