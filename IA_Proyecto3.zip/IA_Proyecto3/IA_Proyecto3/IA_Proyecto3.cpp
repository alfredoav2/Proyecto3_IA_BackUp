// IA_Proyecto3.cpp : Este archivo contiene la función "main". La ejecución del programa comienza y termina ahí.
//

#include <iostream>
#include "Gato.h"
#include "Maze.h"
int main()
{

    /*Maze maze;
    maze.Start();*/
    Gato gato;
    gato.Start();
    /*Tree<int> a;
    a.insert(0, 0);
    a.insert(0, 1);
    a.insert(0, 2);
    a.insert(0, 3);
    a.insert(1, 4);
    a.insert(1, 5);
    a.insert(2, 9);
    a.insert(2, 8);
    a.insert(2, 7);
    a.insert(3, 13);
    a.insert(3, 24);
    a.insert(3, 11);
    a.insert(3, 10);
    a.insert(3, 16);
    a.insert(8, 15);
    a.insert(8, 6);
    a.insert(18, 20);
    a.insert(14, 21);
    a.insert(24, 30);
    a.insert(15, 24);
    std::cout << "Hello World!\n";

    cout << "Arbol :" << endl;
    a.imprime();*/
}

// Ejecutar programa: Ctrl + F5 o menú Depurar > Iniciar sin depurar
// Depurar programa: F5 o menú Depurar > Iniciar depuración

// Sugerencias para primeros pasos: 1. Use la ventana del Explorador de soluciones para agregar y administrar archivos
//   2. Use la ventana de Team Explorer para conectar con el control de código fuente
//   3. Use la ventana de salida para ver la salida de compilación y otros mensajes
//   4. Use la ventana Lista de errores para ver los errores
//   5. Vaya a Proyecto > Agregar nuevo elemento para crear nuevos archivos de código, o a Proyecto > Agregar elemento existente para agregar archivos de código existentes al proyecto
//   6. En el futuro, para volver a abrir este proyecto, vaya a Archivo > Abrir > Proyecto y seleccione el archivo .sln
